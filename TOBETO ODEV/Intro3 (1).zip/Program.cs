﻿//// See https://aka.ms/new-console-template for more information
//using Intro3;

//Console.WriteLine("Hello, World!");

//string firstName = "Rümeysa Bircan";

//Course course1 = new Course();
//course1.Id = 1;
//course1.Name = "C#";
//course1.Description = "C# OOP Dersleri";
//course1.InstructorId = 1;
//course1.Price = 0;

//Course course2 = new Course();
//course2.Id = 2;
//course2.Name = "Java";
//course2.Description = "Java OOP Dersleri";
//course2.InstructorId = 1;
//course2.Price = 0;

//course1 = course2;
//course2.Name = "Javascript";
//Console.WriteLine(course1.Name); //js

////class interface array diziler coleksiyonlar referans tip ..
////new görünce bellekte heapte kısımında yer açıldı ve heap e işlendi özellikleri

//int number1 = 10; //değer tipler sayısal seapta olduğundan sadece istenilen değer etkileniyor
//int number2 = 20;

//number1 = number2;
//number2 = 30;

//Console.WriteLine(number1); //20

//// int,double,...bool =value types

//bool isItTrue1 = false;
//bool isItTrue2 = true;
//isItTrue1 = isItTrue2;
//isItTrue2 = false;

//Console.WriteLine(isItTrue1);//true







/* class
 * categories
 * instructor
 * courses
 */

using Intro3;

Course courseJavascript = new Course();
courseJavascript.Id = 1;
courseJavascript.InstructorId = 1;
courseJavascript.CategoryId = 1;
courseJavascript.Name = "Javascript";
courseJavascript.Description = "Javascript Course";
courseJavascript.Price = 100;

Course coursePython = new Course();
coursePython.Id = 2;
coursePython.InstructorId = 2;
coursePython.CategoryId = 1;
coursePython.Name = "Python";
coursePython.Description = "Python Course";
coursePython.Price = 100;

Course courseJava = new Course();
courseJava.Id = 3;
courseJava.InstructorId = 1;
courseJava.CategoryId = 1;
courseJava.Name = "Java";
courseJava.Description = "Java Course";
courseJava.Price = 100;

Course courseCSharp = new Course();
courseCSharp.Id = 4;
courseCSharp.InstructorId = 1;
courseCSharp.CategoryId = 1;
courseCSharp.Name = "CSharp";
courseCSharp.Description = "CSharp Course";
courseCSharp.Price = 100;

Course courseReact = new Course();
courseReact.Id = 5;
courseReact.InstructorId = 1;
courseReact.CategoryId = 1;
courseReact.Name = "React";
courseReact.Description = "React Course";
courseReact.Price = 100;






