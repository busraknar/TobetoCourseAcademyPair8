﻿
using Entities.Concretes;
using Business.Concretes;

//Category category1 = new Category();
//category1.Id = 1;
//category1.Name = "Programlama";

Course course1=new Course();
course1.Id = 1;
course1.Name = "Js";
course1.CategoryId = 2;
course1.Title = "Javascript";
//CategoryManager categoryManager=new CategoryManager();
//categoryManager.Add(course1);

//Course course2 = new Course();    
//course2.Id = 1;
//course2.Name = "Java Dersleri";
//categoryManager.Add(course2);

DataManager dataManager = new DataManager();
dataManager.Add(course1);
